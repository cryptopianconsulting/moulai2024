package com.mycompany.moula

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
