import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';

class SelectPersonalDeductionModel extends FlutterFlowModel {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Checkbox1 widget.
  bool? checkbox1Value;
  // State field(s) for Checkbox2 widget.
  bool? checkbox2Value;
  // State field(s) for Checkbox3 widget.
  bool? checkbox3Value;
  // State field(s) for Checkbox4 widget.
  bool? checkbox4Value;
  // State field(s) for Checkbox5 widget.
  bool? checkbox5Value;
  // State field(s) for Checkbox6 widget.
  bool? checkbox6Value;
  // State field(s) for Checkbox7 widget.
  bool? checkbox7Value;
  // State field(s) for Checkbox8 widget.
  bool? checkbox8Value;
  // State field(s) for Checkbox9 widget.
  bool? checkbox9Value;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {}

  /// Additional helper methods are added here.

}
