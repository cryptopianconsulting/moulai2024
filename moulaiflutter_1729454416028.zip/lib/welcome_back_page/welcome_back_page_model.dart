import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';

class WelcomeBackPageModel extends FlutterFlowModel {
  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {}

  /// Additional helper methods are added here.

}
